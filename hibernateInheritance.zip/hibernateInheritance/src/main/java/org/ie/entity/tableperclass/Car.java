package org.ie.entity.tableperclass;

import javax.persistence.Entity;

@Entity
public class Car extends Vehicle {
    private String model;
    private String owner;
    private String type;

    public void setModel(String model) {
        this.model = model;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getModel() {
        return model;
    }

    public String getOwner() {
        return owner;
    }

    public String getType() {
        return type;
    }
}
