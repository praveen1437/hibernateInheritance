package org.ie.entity.join;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;

/**
 * this demonstrates table per class type inheritance mapping in the database
 * each table join id is placed to map whenever we need it
 * strategy type used is join
 */
@Entity
@Inheritance(strategy = InheritanceType.JOINED)
public class Watch {
    @Id
    private int id;
    private String BrandName;

    public void setId(int id) {
        this.id = id;
    }

    public void setBrandName(String brandName) {
        BrandName = brandName;
    }

    public int getId() {
        return id;
    }

    public String getBrandName() {
        return BrandName;
    }
}
