package org.ie.entity.join;

import javax.persistence.Entity;

@Entity

public class SmartWatch  extends  Watch{
    private String displayColor;
    private  double MicWaveLengthKHZ;
    private double sizeOfMicroPhone;

    public void setDisplayColor(String displayColor) {
        this.displayColor = displayColor;
    }

    public void setMicWaveLengthKHZ(double micWaveLengthKHZ) {
        MicWaveLengthKHZ = micWaveLengthKHZ;
    }

    public void setSizeOfMicroPhone(double sizeOfMicroPhone) {
        this.sizeOfMicroPhone = sizeOfMicroPhone;
    }

    public String getDisplayColor() {
        return displayColor;
    }

    public double getMicWaveLengthKHZ() {
        return MicWaveLengthKHZ;
    }

    public double getSizeOfMicroPhone() {
        return sizeOfMicroPhone;
    }
}
