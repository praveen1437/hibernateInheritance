package org.ie.entity.tableperclass;

import com.sun.javafx.beans.IDProperty;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;

@Entity
@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
public class Vehicle {
    @Id
    private int vehicleID;
    private String BrandName;

    public void setVehicleID(int vehicleID) {
        this.vehicleID = vehicleID;
    }

    public void setBrandName(String brandName) {
        BrandName = brandName;
    }

    public int getVehicleID() {
        return vehicleID;
    }

    public String getBrandName() {
        return BrandName;
    }
}
