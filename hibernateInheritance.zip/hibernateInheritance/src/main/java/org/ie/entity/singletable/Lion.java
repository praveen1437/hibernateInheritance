package org.ie.entity.singletable;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("Wild")
public class Lion extends Animal {
    private double age;

    public void setAge(double age) {
        this.age = age;
    }

    public double getAge() {
        return age;
    }
}
