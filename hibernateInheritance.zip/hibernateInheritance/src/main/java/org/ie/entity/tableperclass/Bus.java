package org.ie.entity.tableperclass;

import javax.persistence.Entity;

@Entity
public class Bus extends Vehicle {
    private String type;
    private double capacity;

    public void setType(String type) {
        this.type = type;
    }

    public void setCapacity(double capacity) {
        this.capacity = capacity;
    }

    public void setBhp(double bhp) {
        this.bhp = bhp;
    }

    public String getType() {
        return type;
    }

    public double getCapacity() {
        return capacity;
    }

    public double getBhp() {
        return bhp;
    }

    private double bhp;
}
