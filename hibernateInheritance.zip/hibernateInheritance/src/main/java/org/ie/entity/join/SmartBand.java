package org.ie.entity.join;

import javax.persistence.Entity;

@Entity
public class SmartBand extends Watch {
    private String displayColor;

    public void setDisplayColor(String displayColor) {
        this.displayColor = displayColor;
    }

    public String getDisplayColor() {
        return displayColor;
    }
}
